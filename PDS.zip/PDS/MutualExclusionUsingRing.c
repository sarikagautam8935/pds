#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

typedef struct resources {
    int A;
    char B;
    int C;
    char D;
} resources;

void CriticalSection() {
    resources R;
    FILE *f;
    
    f = fopen("shared_mem.txt", "r");
    fread(&R, sizeof(R), 1, f);
    fclose(f);
    
    printf("Read %d, %d, %d, %d from memory\n", R.A, R.B, R.C, R.D);
    printf("Working on data\n");
    
    R.A += 1;
    R.B += 1;
    R.C += 1;
    R.D += 1;
    
    f = fopen("shared_mem.txt", "w");
    fwrite(&R, sizeof(R), 1, f);
    fclose(f);
}

int Connect(int P) {
    int sockid;
    int op_val;
    struct sockaddr_in serv_add;

    if ((sockid = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("Socket Failed\n");
        exit(EXIT_FAILURE);
    }

    setsockopt(sockid, SOL_SOCKET, SO_REUSEADDR, (const void *)&op_val, sizeof(int));
    memset(&serv_add, 0, sizeof(serv_add));
    
    serv_add.sin_family = AF_INET;
    serv_add.sin_addr.s_addr = INADDR_ANY;
    serv_add.sin_port = htons(P);

    if (bind(sockid, (const struct sockaddr *)&serv_add, sizeof(serv_add)) < 0) {
        perror("Bind Error");
        exit(EXIT_FAILURE);
    }

    return sockid;
}

int main(int argc, char const *argv[]) {
    int Add, Dest, Own;
    Add = atoi(argv[1]);
    Dest = atoi(argv[2]);
    Own = atoi(argv[3]);

    printf("My address: %d Next Node: %d Permission: %d\n", Add, Dest, Own);
    printf("Making a node at my address = %d\n", Add);

    int sock_id = Connect(Add);
    struct sockaddr_in next_node, prev_node;
    int len, n;
    char resp[1024];
    char buff[1024];

    memset(&next_node, 0, sizeof(next_node));
    next_node.sin_family = AF_INET;
    next_node.sin_addr.s_addr = INADDR_ANY;
    next_node.sin_port = htons(Dest);

    if (Own) {
        printf("Entering Critical Section\n");
        CriticalSection();
        strcpy(resp, "ACK");
        int c = sendto(sock_id, (const char *)resp, strlen(resp), MSG_CONFIRM,
                       (const struct sockaddr *)&next_node, sizeof(next_node));

        memset(&prev_node, 0, sizeof(prev_node));
        int n = recvfrom(sock_id, (char *)buff, 1024, MSG_WAITALL,
                         (struct sockaddr *)&prev_node, &len);
        buff[n] = '\0';

        if (strcmp(buff, "ACK")) {
            strcpy(resp, "TERM");
            int c = sendto(sock_id, (const char *)resp, strlen(resp), MSG_CONFIRM,
                           (const struct sockaddr *)&next_node, sizeof(next_node));
            printf("sent to %d DONE, process exit\n", c);
        } else {
            printf("Error message\n");
        }

        exit(0);
    } else {
        while (1) {
            memset(&prev_node, 0, sizeof(prev_node));
            int n = recvfrom(sock_id, (char *)buff, 1024, MSG_WAITALL,
                             (struct sockaddr *)&prev_node, &len);
            buff[n] = '\0';

            if (!(strcmp(buff, "ACK"))) {
                CriticalSection();
                sendto(sock_id, (const char *)buff, strlen(buff), MSG_CONFIRM,
                       (const struct sockaddr *)&next_node, sizeof(next_node));
            } else if (!(strcmp(buff, "TERM"))) {
                sendto(sock_id, (const char *)buff, strlen(buff), MSG_CONFIRM,
                       (const struct sockaddr *)&next_node, sizeof(next_node));
                printf("Exit\n");
                exit(0);
            } else {
                printf("Invalid message\n");
            }
        }
    }

    return 0;
}
