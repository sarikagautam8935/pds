import multiprocessing

def increment_counter(counter):
    for _ in range(1000000):
        counter.value += 1

if __name__ == "__main__":
    counter = multiprocessing.Value("i", 0)

    processes = []
    for _ in range(4):  # You can adjust the number of processes as needed
        process = multiprocessing.Process(target=increment_counter, args=(counter,))
        processes.append(process)

    for process in processes:
        process.start()

    for process in processes:
        process.join()

    print("Final Counter Value:", counter.value)
