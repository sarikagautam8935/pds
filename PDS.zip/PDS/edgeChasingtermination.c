#include<stdio.h>
#include<conio.h>
void main()
{
int temp,process[10][15], site_count=0, process_count=0,i,j,k,waiting[15];
int p1,p2,p3;
printf("\n Enter the no. of sites (max 3) \n");
scanf("%d",&site_count);
for(i=1;i<=site_count;i++)
{
printf("\n Enter the no. of processes in %d site ( max 4)\n",i);
scanf("%d",&process_count);
for(j=0;j<process_count;j++)
{
process[i][j]=i+(i*j);
}
}
printf("\n Enter the blocked process \n");
scanf("%d",&k);
for(i=1;i<=3;i++)
{
for(j=0;j<=3;j++)
{
if(k==process[i][j])
{
printf("Process %d is at site %d ",k,i);
temp=i;
}
if(k==process[i][j])
printf("It is a deadlock \n");
if(k==(process[temp][j])&&((process[temp][j])==waiting[process[i][j]]) && (temp!=i))
{
//probe(temp,j,process[i][j]);
if(process[i][j]==waiting[process[temp][j]]);
printf("It is a deadlock\n");
}
}
}getch();}
/*
Sample Input:
Enter the no. of sites (max 3)
3
Enter the no. of processes in each site (max 4): 4

Sample Output:

Enter the blocked process: 8

Sample Output:
Enter the no. of processes in 1 site (max 4): 
Enter the no. of processes in 2 site (max 4): 
Enter the no. of processes in 3 site (max 4): 
Process 8 is at site 3

*/