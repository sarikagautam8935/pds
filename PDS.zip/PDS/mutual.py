import socket
import struct

class Resources:
    def __init__(self, A, B, C, D):
        self.A = A
        self.B = B
        self.C = C
        self.D = D

def critical_section():
    with open("shared_mem.txt", "r") as f:
        data = f.read()
        R = Resources(*struct.unpack("iiii", data))

    print(f"Read {R.A}, {R.B}, {R.C}, {R.D} from memory")
    print("Working on data")

    R.A += 1
    R.B += 1
    R.C += 1
    R.D += 1

    with open("shared_mem.txt", "w") as f:
        f.write(struct.pack("iiii", R.A, R.B, R.C, R.D))

def connect(P):
    sockid = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sockid.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    serv_add = ('', P)

    sockid.bind(serv_add)

    return sockid

def main():
    Add, Dest, Own = map(int, input().split())

    print(f"My address: {Add} Next Node: {Dest} Permission: {Own}")
    print(f"Making a node at my address = {Add}")

    sock_id = connect(Add)

    next_node = ('', Dest)
    prev_node = ('', 0)
    lenn = 1024
    resp = ""
    buff = ""

    if Own:
        print("Entering Critical Section")
        critical_section()
        resp = "ACK"
        sock_id.sendto(resp.encode(), next_node)
        buff, prev_node = sock_id.recvfrom(1024)
        buff = buff.decode()

        if buff != "ACK":
            resp = "TERM"
            sock_id.sendto(resp.encode(), next_node)
            print(f"sent to {prev_node} DONE, process exit")
        else:
            print("Error message")

        exit(0)
    else:
        while True:
            buff, prev_node = sock_id.recvfrom(1024)
            buff = buff.decode()

            if buff == "ACK":
                critical_section()
                sock_id.sendto(buff.encode(), next_node)
            elif buff == "TERM":
                sock_id.sendto(buff.encode(), next_node)
                print("Exit")
                exit(0)
            else:
                print("Invalid message")

if __name__ == "__main__":
    main()
