#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main()
{
int i,d,p,a,c=0,aa[10],j,n;
char ch='y';
printf("enter no of processes");
scanf("%d",&n);
i=0;
do
{
printf("enter the process no which want to execute critical section");
scanf("%d",&a);
aa[i]=a;
i++;
c=c+1;
d=i;
printf("some other process want to execute cs? then press y");
fflush(0);
scanf("%c",&ch);
}
while(ch=='y');
for(j=1;j<=c;j++)
{
printf("\ncritical section is executing for process %d in queue......",j);
printf("\ncritical section is finished for process %d",j);
printf("\nrelease msg has sent by process%d",j);
}
getch();
}