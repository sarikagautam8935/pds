#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<stdlib.h>
#include<math.h>
void main()
{
int i,j,k=0,n,tw,total=0,we,ca,w[20];
printf("enter the no of process=");
scanf("%d",&n);
printf("\n\nassign a controlling agent=");
scanf("%d",&ca);
printf("\n\nenter the total weight=");
scanf("%d",&tw);
while((k<n))
{
randomize();
w[k]=random(tw);
tw=tw-w[k];
k++;
}
for(k=0;k<n;k++)
{total=total+w[k];
}
printf("%d",total);
w[n-1]=abs(tw-total);
printf("%d",w[n-1]);
printf("\n\n\t\t\t\tControlling agent%d %d\n\n\n",ca,w[ca]);
printf("\n\nsending computational message to...\n\n");
for(j=0;j<n;j++)
{
if(j!=(ca-1))
{
sound(700);
delay(2000);
printf("\tprocess%d %d",j+1,w[j]);
}}
nosound();
getch();
}