import random
import time

def main():
    k = 0
    total = 0
    
    n = int(input("Enter the no of process= "))
    ca = int(input("\nAssign a controlling agent= "))
    tw = int(input("\nEnter the total weight= "))
    
    weights = []
    while k < n:
        weight = random.randint(0, tw)
        weights.append(weight)
        tw -= weight
        k += 1
    
    total = sum(weights)
    
    weights[-1] = abs(tw - total)
    
    print(f"\n\n\t\t\t\tControlling agent {ca} {weights[ca-1]}\n\n\n")
    print("\n\nSending computational message to...\n\n")
    
    for j, weight in enumerate(weights, 1):
        if j != ca:
            print(f"\tprocess{j} {weight}")
            time.sleep(2)
    
if __name__ == "__main__":
    main()
