import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;



public class RMI_ServerFact extends UnicastRemoteObject implements RMI_InterfaceFact{
    public RMI_ServerFact() throws RemoteException{
        super();
    }

    @Override
    public double computeFactorial(double n) throws RemoteException{
        if(n == 1)  
            return 1;
        return n*computeFactorial(n-1);
    }
    public static void main(String[] args) {
        try{
            Registry registry = LocateRegistry.createRegistry(7777); 
            registry.bind("fact", new RMI_ServerFact());
            System.out.println("The RMI Factorial App is running and ready...");
        }catch(Exception e){
            System.out.println("Error : The RMI Factorial App is not running...");

        }
    }
}
/*
pritam@pritam-GF63-Thin-9SCSR:~/Downloads/PDS$ cd RMI
pritam@pritam-GF63-Thin-9SCSR:~/Downloads/PDS/RMI$ javac RMI_Client.java
pritam@pritam-GF63-Thin-9SCSR:~/Downloads/PDS/RMI$ java RMI_Client 
*******************************************
THE RMI App for Factorial and Sum upto N

Enter number for factorial : 
5
Enter number for Sum : 
8
Factorial : 120.0
Sum upto given n: 36.0
Sum : 156.0

*/

/*pritam@pritam-GF63-Thin-9SCSR:~/Downloads/PDS$ cd "/home/pritam/Downloads/PDS/RMI/" && javac RMI_ServerFact.java && java RMI_ServerFact
The RMI Factorial App is running and ready...
*/
