import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;



public class RMI_ServerSumN extends UnicastRemoteObject implements RMI_InterfaceSumN{
    public RMI_ServerSumN() throws RemoteException{
        super();
    }

    @Override
    public double sumUptoN(double n) throws RemoteException{
        return (n*(n+1))/2;
    }

    public static void main(String[] args) {
        try{
            Registry registry = LocateRegistry.createRegistry(8888); 
            registry.bind("sumn", new RMI_ServerSumN());
            System.out.println("The RMI Sum App is running and ready...");
        }catch(Exception e){
            System.out.println("Error : The RMI Sum App is not running...");

        }
    }
}
/*
pritam@pritam-GF63-Thin-9SCSR:~/Downloads/PDS$ cd "/home/pritam/Downloads/PDS/RMI/" && javac RMI_ServerFact.java && java RMI_ServerSumN
The RMI Sum App is running and ready...*/
