def main():
    process = [[0] * 15 for _ in range(10)]
    site_count = 0
    process_count = 0
    waiting = [0] * 15

    print("\nEnter the no. of sites (max 3) ")
    site_count = int(input())

    for i in range(1, site_count + 1):
        print("\nEnter the no. of processes in {} site (max 4)".format(i))
        process_count = int(input())

        for j in range(process_count):
            process[i][j] = i + (i * j)

    print("\nEnter the blocked process")
    k = int(input())

    found = False

    for i in range(1, site_count + 1):
        for j in range(4):
            if k == process[i][j]:
                print("Process {} is at site {}".format(k, i))
                temp = i
                found = True

    if not found:
        print("Process {} not found in any site".format(k))

    for i in range(1, 4):
        for j in range(4):
            if found and k == process[temp][j] and (process[temp][j] == waiting[process[i][j]]) and (temp != i):
                # probe(temp, j, process[i][j])
                if process[i][j] == waiting[process[temp][j]]:
                    print("It is a deadlock")


if __name__ == "__main__":
    main()
