#include<stdio.h>
#include<conio.h>
void main()
{
int a=0;
char b,c;
do
{
printf("if transaction T1 want to lock data object");
fflush(0);
scanf("%c",&b);
if(a==0 && b=='y')
{
a=1;
b='n';
}
else if(a==1)
printf("data object is locked");
printf("if transaction T2 want to lock data object");
fflush(0);
scanf("%c",&b);
if(a==0 && b=='y')
{
a=1;
b='n';
}
else
printf("data object is locked");
printf("\nif transaction want to release data object");
fflush(0);
scanf("%c",&b);
if(a==1 && b=='y')
a=0;
printf("do you want to continue");
fflush(0);
scanf("%c",&c);
}while(c=='y');
getch();
}
/*
if transaction T1 wants to lock data object (y/n): y
data object is locked
if transaction T2 wants to lock data object (y/n): n
data object is locked
if transaction wants to release data object (y/n): y
do you want to continue (y/n): y
if transaction T1 wants to lock data object (y/n): n
if transaction T2 wants to lock data object (y/n): y
data object is locked
if transaction wants to release data object (y/n): n
do you want to continue (y/n): n

*/