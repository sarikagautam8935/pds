import time
import random

def process1(i, ran_pr, p):
    global count
    for j in range(ran_pr):
        if i != j:
            print(f"Process P{p[i]} is sending request to P{p[j]}")
    print("\n")
    for j in range(ran_pr):
        if i != j:
            print(f"Process P{p[j]} is acknowledging P{p[i]}")
            count += 1
    print("\n")
    if count == (ran_pr - 1):
        print(f"Process P{p[i]} is entering CS")
        time.sleep(1)
    print("\n")
    for j in range(ran_pr):
        if i != j:
            print(f"Process P{p[i]} is sending reply to P{p[j]}")

def process2(i, ran_pr, n, p):
    global count
    for j in range(ran_pr + 1, n):
        if i != j:
            print(f"Process P{p[i]} is sending request to P{p[j]}")
    print("\n")
    for j in range(ran_pr + 1, n):
        if i != j:
            print(f"Process P{p[j]} is acknowledging P{p[i]}")
            count += 1
    print("\n")
    if count == (n - ran_pr - 1):
        print(f"Process P{p[i]} is entering CS")
        time.sleep(1)
    print("\n")
    for j in range(ran_pr + 1, n):
        if i != j:
            print(f"Process P{p[i]} is sending reply to P{p[j]}")

if __name__ == "__main__":
    count = 0
    n = int(input("Enter the no. of processes: "))
    p = [i + 1 for i in range(n)]

    ran_pr = 3  # You can replace this with random.randint(0, n - 1) to get a random number between 0 and n-1
    print(f"Control process is P{ran_pr}")
    
    print("Enter the priority of processes:")
    pr = [int(input(f"Priority of process P{p[i]}: ")) for i in range(n)]

    for i in range(n - 1):
        for j in range(i + 1, n):
            if pr[i] > pr[j]:
                pr[i], pr[j] = pr[j], pr[i]
                p[i], p[j] = p[j], p[i]

    for i in range(n - 1):
        if p[i] < ran_pr:
            max_lmt = ran_pr
            process1(i, ran_pr, p)
        else:
            min_lmt = ran_pr + 1
            process2(i, ran_pr, n, p)


'''OUTPUT:
Enter the no. of processses 5
Control process is P3
Enter the priority of processes
Priority of process P1 :2
Priority of process P2 :1
Priority of process P3 :5
Priority of process P4 :3
Priority of process P5 :4

Process P2 is sending request to P1
Process P2 is sending request to P3
Process P1 is acknowledging P2
Process P3 is acknowledging P2
Process P2 is entering CS
Process P2 is sending reply to P1
Process P2 is sending reply to P3

Process P1 is sending request to P2
Process P1 is sending request to P3
Process P2 is acknowledging P1
Process P3 is acknowledging P1
Process P1 is entering CS
Process P1 is sending reply to P2
Process P1 is sending reply to P3

Process P4 is sending request to P5
Process P5 is acknowledging P4
Process P4 is entering CS
Process P4 is sending reply to P5

Process P5 is sending request to P4
Process P4 is acknowledging P5
Process P5 is entering CS
Process P5 is sending reply to P4

Process P3 is sending request to P1
Process P3 is sending request to P2
Process P1 is acknowledging P3
Process P2 is acknowledging P3
Process P5 is entering CS
Process P3 is sending reply to P1
Process P3 is sending reply to P2
'''