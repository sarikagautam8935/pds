import random
import numpy as np

# Constants
BOARD_SIZE = int(input("Enter the board size (e.g., 8 for 8-Queens problem): "))
POPULATION_SIZE = int(input("Enter the population size: "))
MUTATION_RATE = float(input("Enter the mutation rate (e.g., 0.1 for 10%): "))
MAX_GENERATIONS = int(input("Enter the maximum number of generations: "))

def initialize_population():
    population = []
    for _ in range(POPULATION_SIZE):
        chromosome = list(range(BOARD_SIZE))
        random.shuffle(chromosome)
        population.append(chromosome)
    return population

def fitness(chromosome):
    conflicts = 0
    for i in range(BOARD_SIZE):
        for j in range(i + 1, BOARD_SIZE):
            if chromosome[i] == chromosome[j] or abs(i - j) == abs(chromosome[i] - chromosome[j]):
                conflicts += 1
    return conflicts

def selection(population):
    fitness_values = [fitness(chromosome) for chromosome in population]
    total_fitness = sum(fitness_values)
    probabilities = [fit / total_fitness for fit in fitness_values]
    selected_indices = np.random.choice(range(POPULATION_SIZE), size=POPULATION_SIZE, p=probabilities)
    return [population[i] for i in selected_indices]

def crossover(parent1, parent2):
    crossover_point = random.randint(1, BOARD_SIZE - 1)
    child1 = parent1[:crossover_point] + [gene for gene in parent2 if gene not in parent1[:crossover_point]]
    child2 = parent2[:crossover_point] + [gene for gene in parent1 if gene not in parent2[:crossover_point]]
    return child1, child2

def mutate(chromosome):
    if random.random() < MUTATION_RATE:
        i, j = random.sample(range(BOARD_SIZE), 2)
        chromosome[i], chromosome[j] = chromosome[j], chromosome[i]

def genetic_algorithm():
    population = initialize_population()
    for generation in range(MAX_GENERATIONS):
        population = selection(population)
        new_population = []
        while len(new_population) < POPULATION_SIZE:
            parent1, parent2 = random.sample(population, 2)
            child1, child2 = crossover(parent1, parent2)
            mutate(child1)
            mutate(child2)
            new_population.extend([child1, child2])
        population = new_population
        best_solution = min(population, key=fitness)
        if fitness(best_solution) == 0:
            return best_solution
    return None

def print_solution(solution):
    for row in range(BOARD_SIZE):
        line = ""
        for col in range(BOARD_SIZE):
            if solution[col] == row:
                line += "Q "
            else:
                line += ". "
        print(line)

if __name__ == "__main__":
    solution = genetic_algorithm()
    if solution:
        print("Found a solution:")
        print_solution(solution)
    else:
        print("No solution found within the maximum number of generations.")
