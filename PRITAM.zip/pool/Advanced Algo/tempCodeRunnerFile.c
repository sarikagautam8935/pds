 char text[100]; //= "ABABDABACDABABCABAB";
    char pattern[10]; //= "BA";